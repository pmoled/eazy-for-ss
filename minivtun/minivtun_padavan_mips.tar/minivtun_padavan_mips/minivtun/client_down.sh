#!/bin/sh
ROOT_DIR="$(cd "$(dirname $0)"; pwd)"
CONFIG="$ROOT_DIR/client.conf"
source $CONFIG
Table_Number=101

ip route flush table ${Table_Number}
ip rule del from ${Speed_IP} table ${Table_Number}
ip rule del to ${Speed_IP} table ${Table_Number}
ip rule del table ${Table_Number} 2>/dev/null

iptables -t mangle -D FORWARD -o ${intf} -p tcp -m tcp --tcp-flags SYN,RST SYN  -j TCPMSS --clamp-mss-to-pmtu
iptables -t nat -D POSTROUTING -s ${Speed_IP} -o ${intf} -j MASQUERADE

