#!/bin/sh
ROOT_DIR="$(cd "$(dirname $0)"; pwd)"
CONFIG="$ROOT_DIR/client.conf"
source $CONFIG
Table_Number=101


#ip rule add table ${Table_Number}
ip route flush table ${Table_Number}

ip rule add from ${Speed_IP} table ${Table_Number}
ip rule add to ${Speed_IP} table ${Table_Number}

ip route add ${server} via $(ip route show 0/0 | sed -e 's/.* via \([^ ]*\).*/\1/') table ${Table_Number}
ip route add default via ${remote_tun_ip} dev ${intf} table ${Table_Number}
ip route show table main | grep -Ev ^default | while read ROUTE ; do ip route add table ${Table_Number} ${ROUTE} ; done

iptables -t mangle -A FORWARD -o ${intf} -p tcp -m tcp --tcp-flags SYN,RST SYN  -j TCPMSS --clamp-mss-to-pmtu
iptables -t nat -A POSTROUTING -s ${Speed_IP} -o ${intf} -j MASQUERADE
